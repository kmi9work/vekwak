class Section < ActiveRecord::Base
  has_many :topics
end
