class Voting < ActiveRecord::Base
  belongs_to :topic
end
