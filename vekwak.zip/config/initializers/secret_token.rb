# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Vekwak::Application.config.secret_token = '337d3b024b3bea0b92f393dde4cbfe7c2f1b3586513695f3e8abb72c4cc6bbc8b792ee3e1475ce2b7303ce089853e481835c64c0944888eee816a2ceac2d1ae4'
